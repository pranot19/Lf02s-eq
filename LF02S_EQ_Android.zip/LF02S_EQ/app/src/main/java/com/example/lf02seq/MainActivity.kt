package com.example.lf02seq

import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val vm: EqViewModel by viewModels()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val d = IntentCompat.getParcelableExtra(i, UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            when (i.action) {
                UsbHidController.ACTION ->
                    vm.onPermission(d, i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                UsbManager.ACTION_USB_DEVICE_DETACHED ->
                    if (d?.vendorId == UsbHidController.VID) vm.onDetached()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = IntentFilter(UsbHidController.ACTION).apply { addAction(UsbManager.ACTION_USB_DEVICE_DETACHED) }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) vm.connect()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { EqScreen(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) vm.connect()
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}

private val TYPES = listOf(0 to "Peaking", 4 to "Low-Shelf", 3 to "High-Shelf", 1 to "Low-Pass", 2 to "High-Pass", 5 to "Notch")
private fun db(g: Float) = String.format(Locale.US, "%+.1f", g)
private fun hz(f: Int) = if (f >= 1000) String.format(Locale.US, "%.1fk", f / 1000f).replace(".0k", "k") else "$f"

@Composable
fun EqScreen(vm: EqViewModel) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }

    var sel by remember { mutableIntStateOf(0) }
    var chosen by remember { mutableStateOf("") }
    var showSave by remember { mutableStateOf(false) }
    var showBurn by remember { mutableStateOf(false) }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(vm.exportJson().toByteArray()) } }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { ctx.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> vm.importJson(r.readText()) } }
    }

    Scaffold(snackbarHost = { SnackbarHost(snack) }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("LF02S Parametric 10-Band EQ", style = MaterialTheme.typography.titleLarge)

            Card2 {
                Button(onClick = { vm.connect() }, Modifier.fillMaxWidth(), enabled = !vm.connected) {
                    Text(if (vm.connected) "เชื่อมต่อสำเร็จแล้ว" else "เชื่อมต่อบอร์ด LF02S (USB OTG)")
                }
                Text(vm.status, style = MaterialTheme.typography.bodySmall)
            }

            Card2 {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Music Out EQ (0x87)", style = MaterialTheme.typography.titleMedium)
                    FilledTonalButton(onClick = { showBurn = true }) { Text("💾 บันทึกลง Flash") }
                }
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    vm.bands.forEachIndexed { i, b ->
                        Column(Modifier.width(58.dp).clickable { sel = i }, horizontalAlignment = Alignment.CenterHorizontally) {
                            val c = if (i == sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            Text(db(b.gain), fontSize = 12.sp, color = c)
                            VSlider(b.gain, { sel = i; vm.setGain(i, (it * 2).roundToInt() / 2f) }, -18f..18f,
                                Modifier.width(48.dp).height(190.dp))
                            Text(hz(b.freq), fontSize = 11.sp, color = c)
                        }
                    }
                }
                val b = vm.bands[sel]
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("f$sel")
                    NumField("Hz", b.freq.toString(), Modifier.weight(1f)) { s -> s.toIntOrNull()?.let { vm.setFreq(sel, it) } }
                    NumField("Q", String.format(Locale.US, "%.2f", b.q), Modifier.weight(1f)) { s -> s.toFloatOrNull()?.let { vm.setQ(sel, it) } }
                    TypeMenu(b.type) { vm.setType(sel, it) }
                }
                Text("สไตล์เสียง", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Protocol.PRESETS.keys.forEach { n -> AssistChip(onClick = { vm.applyBuiltin(n) }, label = { Text(n) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    var menu by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { menu = true }) { Text(chosen.ifEmpty { "Preset ที่บันทึกไว้" }) }
                        DropdownMenu(menu, { menu = false }) {
                            vm.presets.keys.forEach { n ->
                                DropdownMenuItem(text = { Text(n) }, onClick = { chosen = n; vm.loadPreset(n); menu = false })
                            }
                        }
                    }
                    TextButton(onClick = { showSave = true }) { Text("บันทึก") }
                    TextButton(onClick = { if (chosen.isNotEmpty()) { vm.deletePreset(chosen); chosen = "" } }) { Text("ลบ") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportL.launch("LF02S_EQ_Backup.json") }) { Text("Export") }
                    OutlinedButton(onClick = { importL.launch(arrayOf("application/json", "*/*")) }) { Text("Import") }
                }
            }

            Card2 {
                Text("Master Volume (DAC0 0x09): " + String.format(Locale.US, "%02X %02X (%d)", vm.dac and 0xFF, vm.dac shr 8 and 0xFF, vm.dac))
                Slider(vm.dac.toFloat(), { vm.setDac((it / 16).roundToInt() * 16) }, valueRange = 0f..4096f)
                Text("Virtual Bass (0x83): ${vm.vb}")
                Slider(vm.vb.toFloat(), { vm.setVb(it.roundToInt()) }, valueRange = 0f..100f)
            }

            Card2 {
                Text("USB Packet Monitor", style = MaterialTheme.typography.labelMedium)
                Text(vm.monitor, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }

    if (showSave) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("ตั้งชื่อ Preset") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) { vm.savePreset(name.trim()); chosen = name.trim(); showSave = false } }) { Text("บันทึก") } },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text("ยกเลิก") } }
        )
    }
    if (showBurn) {
        AlertDialog(
            onDismissRequest = { showBurn = false },
            title = { Text("บันทึกลง Flash?") },
            text = { Text("บันทึกค่า EQ และ DSP ทั้งหมดลง Flash ของบอร์ด (ปิดเครื่องแล้วค่าไม่หาย)") },
            confirmButton = { TextButton(onClick = { showBurn = false; vm.burn() }) { Text("ยืนยัน") } },
            dismissButton = { TextButton(onClick = { showBurn = false }) { Text("ยกเลิก") } }
        )
    }
}

@Composable
private fun Card2(content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) }

@Composable
private fun NumField(label: String, value: String, modifier: Modifier, onCommit: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    OutlinedTextField(
        text, { text = it }, modifier, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onCommit(text) })
    )
}

@Composable
private fun TypeMenu(type: Int, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(TYPES.firstOrNull { it.first == type }?.second ?: "?") }
        DropdownMenu(open, { open = false }) {
            TYPES.forEach { (t, n) -> DropdownMenuItem(text = { Text(n) }, onClick = { onPick(t); open = false }) }
        }
    }
}

/** สไลเดอร์แนวตั้ง: หมุน Slider 270° แล้วสลับขนาดตอน layout */
@Composable
private fun VSlider(value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>, modifier: Modifier) {
    Slider(
        value, onChange, valueRange = range,
        modifier = modifier
            .layout { m, c ->
                val p = m.measure(Constraints(c.minHeight, c.maxHeight, c.minWidth, c.maxWidth))
                layout(p.height, p.width) { p.place(0, p.width) }
            }
            .graphicsLayer { rotationZ = 270f; transformOrigin = TransformOrigin(0f, 0f) }
    )
}
