package com.example.lf02seq

import android.app.Application
import android.content.Context
import android.hardware.usb.UsbDevice
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

@OptIn(FlowPreview::class)
class EqViewModel(app: Application) : AndroidViewModel(app) {
    private val hid = UsbHidController(app)
    private val prefs = app.getSharedPreferences("lf02s", Context.MODE_PRIVATE)

    var bands by mutableStateOf(Protocol.DEFAULT_BANDS); private set
    var dac by mutableIntStateOf(3824); private set
    var vb by mutableIntStateOf(5); private set
    var connected by mutableStateOf(false); private set
    var status by mutableStateOf("ยังไม่ได้เชื่อมต่อ"); private set
    var monitor by mutableStateOf("พร้อมส่งคำสั่งไปยังบอร์ด LF02S..."); private set
    var presets by mutableStateOf(loadPresets()); private set
    var message by mutableStateOf<String?>(null)

    // ลดความถี่การส่งตอนลากสไลเดอร์ (ส่งค่าล่าสุดทุก ~40 ms)
    private val eqTick = tick(); private val dacTick = tick(); private val vbTick = tick()
    private fun tick() = MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    init {
        viewModelScope.launch(Dispatchers.IO) { eqTick.sample(40).collect { tx(Protocol.eq(bands)) } }
        viewModelScope.launch(Dispatchers.IO) { dacTick.sample(40).collect { tx(Protocol.volume(dac)) } }
        viewModelScope.launch(Dispatchers.IO) { vbTick.sample(40).collect { tx(Protocol.bass(vb)) } }
    }

    private fun tx(p: ByteArray) {
        monitor = p.joinToString(" ") { String.format(Locale.US, "%02X", it) }
        if (connected && hid.send(p) < 0) message = "ส่งข้อมูลไม่สำเร็จ"
    }

    // ---------- USB ----------
    fun connect() {
        val d = hid.findDevice()
            ?: run { message = "ไม่พบบอร์ด LF02S (VID 0x8888) — ต่อสาย OTG แล้วหรือยัง?"; return }
        if (hid.hasPermission(d)) openDevice(d) else hid.requestPermission(d)
    }

    fun onPermission(d: UsbDevice?, granted: Boolean) {
        if (granted && d != null) openDevice(d) else message = "ไม่ได้รับอนุญาตให้ใช้ USB"
    }

    fun onDetached() { hid.close(); connected = false; status = "ยังไม่ได้เชื่อมต่อ" }

    private fun openDevice(d: UsbDevice) = viewModelScope.launch(Dispatchers.IO) {
        val err = hid.open(d)
        if (err != null) { message = err; return@launch }
        connected = true
        status = "เชื่อมต่อแล้ว: ${d.productName ?: "LF02S"}"
        tx(Protocol.HANDSHAKE)
    }

    override fun onCleared() { hid.close() }

    // ---------- EQ ----------
    private fun edit(i: Int, f: (Band) -> Band) {
        bands = bands.toMutableList().also { it[i] = f(it[i]) }
        eqTick.tryEmit(Unit)
    }
    fun setGain(i: Int, g: Float) = edit(i) { it.copy(gain = g) }
    fun setFreq(i: Int, f: Int) = edit(i) { it.copy(freq = f.coerceIn(20, 20000)) }
    fun setQ(i: Int, q: Float) = edit(i) { it.copy(q = q.coerceIn(0.1f, 10f)) }
    fun setType(i: Int, t: Int) = edit(i) { it.copy(type = t) }
    fun setDac(v: Int) { dac = v; dacTick.tryEmit(Unit) }
    fun setVb(v: Int) { vb = v; vbTick.tryEmit(Unit) }

    fun applyBuiltin(name: String) {
        val g = Protocol.PRESETS[name] ?: return
        bands = bands.mapIndexed { i, b -> b.copy(gain = g[i], type = 0) }
        eqTick.tryEmit(Unit)
    }

    fun burn() {
        if (!connected) { message = "กรุณาเชื่อมต่อบอร์ด LF02S ก่อนกดบันทึก"; return }
        viewModelScope.launch(Dispatchers.IO) { tx(Protocol.BURN); message = "💾 สั่งบันทึกลง Flash แล้ว" }
    }

    // ---------- Presets / JSON (รูปแบบเดียวกับไฟล์ Export ของเวอร์ชันเว็บ) ----------
    private fun List<Band>.toJson() = JSONArray().also { a ->
        forEach { a.put(JSONObject().put("freq", it.freq).put("q", it.q.toDouble()).put("gain", it.gain.toDouble()).put("type", it.type)) }
    }
    private fun JSONArray.toBands() = (0 until minOf(length(), 10)).map {
        getJSONObject(it).let { o -> Band(o.getInt("freq"), o.getDouble("q").toFloat(), o.getDouble("gain").toFloat(), o.optInt("type", 0)) }
    }
    private fun loadPresets(): Map<String, List<Band>> {
        val o = JSONObject(prefs.getString("presets", "{}")!!)
        return o.keys().asSequence().associateWith { o.getJSONArray(it).toBands() }
    }
    private fun persist() {
        val o = JSONObject().also { o -> presets.forEach { (k, v) -> o.put(k, v.toJson()) } }
        prefs.edit().putString("presets", o.toString()).apply()
    }
    fun savePreset(name: String) { presets = presets + (name to bands); persist(); message = "บันทึก Preset \"$name\" แล้ว" }
    fun deletePreset(name: String) { presets = presets - name; persist() }
    fun loadPreset(name: String) { presets[name]?.let { bands = it; eqTick.tryEmit(Unit) } }

    fun exportJson(): String =
        JSONObject().put("eqBands", bands.toJson()).put("dac0", dac).put("virtualBass", vb).toString(2)

    fun importJson(s: String) {
        try {
            val n = JSONObject(s).getJSONArray("eqBands").toBands()
            bands = n + bands.drop(n.size)
            eqTick.tryEmit(Unit)
            message = "นำเข้าไฟล์สำเร็จ!"
        } catch (e: Exception) { message = "ไฟล์ JSON ไม่ถูกต้อง" }
    }
}
