package com.example.lf02seq

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.*

/** แทน navigator.hid ของ WebHID ด้วย Android USB Host API */
class UsbHidController(private val ctx: Context) {
    companion object {
        const val ACTION = "com.example.lf02seq.USB_PERMISSION"
        const val VID = 0x8888
    }

    private val usb = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
    private var conn: UsbDeviceConnection? = null
    private var iface: UsbInterface? = null
    private var outEp: UsbEndpoint? = null
    private val lock = Any()

    fun findDevice(): UsbDevice? = usb.deviceList.values.firstOrNull { it.vendorId == VID }
    fun hasPermission(d: UsbDevice) = usb.hasPermission(d)

    fun requestPermission(d: UsbDevice) {
        val pi = PendingIntent.getBroadcast(
            ctx, 0, Intent(ACTION).setPackage(ctx.packageName), PendingIntent.FLAG_MUTABLE
        )
        usb.requestPermission(d, pi)
    }

    /** คืนค่า null ถ้าสำเร็จ ไม่งั้นคืนข้อความ error */
    fun open(d: UsbDevice): String? {
        close()
        val c = usb.openDevice(d) ?: return "เปิดอุปกรณ์ USB ไม่สำเร็จ"
        val i = (0 until d.interfaceCount).map { d.getInterface(it) }
            .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_HID } ?: d.getInterface(0)
        if (!c.claimInterface(i, true)) { c.close(); return "claim interface ไม่สำเร็จ" }
        conn = c; iface = i
        outEp = (0 until i.endpointCount).map { i.getEndpoint(it) }.firstOrNull {
            it.direction == UsbConstants.USB_DIR_OUT && it.type == UsbConstants.USB_ENDPOINT_XFER_INT
        }
        return null
    }

    /** เทียบเท่า hidDevice.sendReport(0, data): ใช้ Interrupt OUT ถ้ามี ไม่งั้น SET_REPORT */
    fun send(data: ByteArray): Int = synchronized(lock) {
        val c = conn ?: return -1
        val ep = outEp
        if (ep != null) c.bulkTransfer(ep, data, data.size, 1000)
        else c.controlTransfer(0x21, 0x09, 0x0200, iface?.id ?: 0, data, data.size, 1000)
    }

    fun close() = synchronized(lock) {
        iface?.let { conn?.releaseInterface(it) }
        conn?.close()
        conn = null; iface = null; outEp = null
    }
}
