package com.example.lf02seq

import kotlin.math.roundToInt

data class Band(val freq: Int, val q: Float, val gain: Float, val type: Int = 0)

/** Packet ทั้งหมดถอดจาก LF02S_EQ_Controller.html (1234.ini) */
object Protocol {
    private fun b(vararg v: Int) = ByteArray(v.size) { v[it].toByte() }

    val DEFAULT_BANDS = listOf(
        Band(100, 0.73f, 0f), Band(161, 0.76f, -0.5f), Band(400, 0.88f, 3f),
        Band(1000, 0.72f, 1f), Band(2500, 0.72f, 0f), Band(4000, 0.71f, -1f),
        Band(6000, 0.70f, -1.5f), Band(10000, 0.58f, -2.5f),
        Band(16000, 0.71f, 0f), Band(20000, 0.71f, 0f),
    )

    val PRESETS = linkedMapOf(
        "ค่าเริ่มต้น 1234.ini" to listOf(0f, -0.5f, 3f, 1f, 0f, -1f, -1.5f, -2.5f, 0f, 0f),
        "Flat" to List(10) { 0f },
        "Bass Heavy" to listOf(8f, 6f, 4f, 1f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Vocal Clarity" to listOf(-2f, -1f, 2f, 5f, 5f, 3f, 1f, 0f, 0f, 0f),
        "Treble Crisp" to listOf(-1f, -1f, 0f, 0f, 1f, 4f, 6f, 8f, 7f, 5f),
        "Rock (V-Shape)" to listOf(7f, 4f, -1f, -3f, -1f, 2f, 5f, 7f, 7f, 7f),
    )

    val HANDSHAKE = b(0xA5, 0x5A, 0xFC, 0x07, 0x4D, 0x75, 0x73, 0x69, 0x63, 0x5F, 0x46, 0x16) // "Music_F"
    val BURN = b(0xA5, 0x5A, 0xFD, 0x00, 0x16) // บันทึกลง Flash

    /** Music Out EQ (0x87): 10 แบนด์ x 10 ไบต์ */
    fun eq(bands: List<Band>): ByteArray {
        val p = ArrayList<Int>(112)
        p += listOf(0xA5, 0x5A, 0x87, 0x6B, 0xFF, 0x01, 0x00, 0xCD, 0x00, 0x00, 0x00)
        bands.take(10).forEach {
            val q = (it.q * 1000).roundToInt()
            val g = (it.gain * 100).roundToInt() // signed 16-bit
            p += listOf(
                0x01, 0x00, it.type, 0x00,
                it.freq and 0xFF, it.freq shr 8 and 0xFF,
                q and 0xFF, q shr 8 and 0xFF,
                g and 0xFF, g shr 8 and 0xFF,
            )
        }
        p += 0x16
        return b(*p.toIntArray())
    }

    /** Master Volume (DAC0 0x09) */
    fun volume(v: Int) = b(
        0xA5, 0x5A, 0x09, 0x1D, 0xFF, if (v == 0) 0x00 else 0x03, 0x00, 0x07, 0x00, 0x00, 0x00,
        v and 0xFF, v shr 8 and 0xFF, v and 0xFF, v shr 8 and 0xFF,
        *IntArray(18), 0x16,
    )

    /** Virtual Bass (0x83) */
    fun bass(v: Int) = b(
        0xA5, 0x5A, 0x83, 0x09, 0xFF, if (v == 0) 0x00 else 0x01, 0x00, v,
        0x00, 0x05, 0x00, 0x00, 0x00, 0x16,
    )
}
